import java.util.Scanner;

public class Zad123 {

    public static int[] ciagArytmetycznyRodzajuM (int n, int m, int a1, int[] r) {
        int[] ciag = new int[n+1];
        if (m == 1){
            for (int i=1; i<=n; i++){
                ciag[i] = a1 + (i-1)* r[0];
                System.out.print(ciag[i] + " ");
            }
        }
        else if (m == 2){
            for (int i=1; i<=n; i++){
                ciag[i] = a1 + (i-1)*r[0] + (i-1)*(i-1)*r[1] ;
                System.out.print(ciag[i] + " ");
            }
        }
        else if (m == 3){
            for (int i=1; i<=n; i++){
                ciag[i] = a1 + (i-1)*r[0] + (i-1)*(i-1)*(i-1)*r[1] + (i-1)*(i-1)*(i-1)*r[2];
                System.out.print(ciag[i] + " ");
            }
        }
        return ciag;
    }

    public static boolean czyCiagArytmetyczny (int[] ciag) {
        int poczatek = ciag[1] - ciag[0];
        boolean test = true;
        if(poczatek == 0){
            test = false;
        }
        for (int i=2; i<ciag.length; i++){
            if (ciag[i] - ciag[i-1] != poczatek){
                test = false;
            }
        }
        return test;
    }

    public static boolean czyCiagArytmetycznyRodzajuM (int[] ciag, int m) {
        boolean test = true;
        if (m == 1) {
            int poczatek = ciag[1] - ciag[0];
            if(poczatek == 0){
                test = false;
            }
            for (int i = 2; i < ciag.length; i++) {
                if (ciag[i] - ciag[i - 1] != poczatek) {
                    test = false;
                }
            }

        } else if (m == 2) {
            int[] ciag2 = new int[ciag.length-1];
            for (int i = 0; i <ciag2.length; i++) {
                ciag2[i] = ciag[i+1] - ciag[i];
                System.out.print(ciag2[i] + " ");
            }
            int poczatek = ciag2[1] - ciag2[0];
            if(poczatek == 0){
                test = false;
            }
            for (int i = 2; i < ciag2.length; i++) {
                if (ciag2[i] - ciag2[i - 1] != poczatek) {
                    test = false;
                }
            }
        }

        else if (m == 3) {
            int[] ciag3 = new int[ciag.length-1];
            for (int i = 0; i <ciag3.length; i++) {
                ciag3[i] = ciag[i+1] - ciag[i];
                System.out.print(ciag3[i] + " ");
            }
            int[] ciag4 = new int[ciag3.length-1];
            for (int i = 0; i <ciag4.length; i++) {
                ciag4[i] = ciag3[i+1] - ciag3[i];
                System.out.print(ciag4[i] + " ");
            }
            int poczatek = ciag4[1] - ciag4[0];
            if(poczatek == 0){
                test = false;
            }
            for (int i = 2; i < ciag4.length; i++) {
                if (ciag4[i] - ciag4[i - 1] != poczatek) {
                    test = false;
                }
            }

        }
        return test;
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        System.out.println("Podaj n: ");
//        int n = sc.nextInt();
        System.out.println("Podaj m: ");
        int m = sc.nextInt();
//        System.out.println("Podaj a1: ");
//        int a1 = sc.nextInt();
        int[] r = {1,8,27,64,125};
//        System.out.println(ciagArytmetycznyRodzajuM(n, m, a1, r));
//        System.out.println(czyCiagArytmetyczny(r));
          System.out.println(czyCiagArytmetycznyRodzajuM(r, m));
    }
}
