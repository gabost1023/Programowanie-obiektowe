public class Zad45 {

    public static int podciag (int[] tab){
        int max = 0;
        int teraz = 1;
        for (int i = 0; i < tab.length-1; i++) {
            if(tab[i] < tab[i+1]){
                teraz++;
                max = Math.max(max, teraz);
            }
            else teraz = 1;
        }
        for (int i = 0; i < tab.length; i++) {
            System.out.print(tab[i] + " ");
        }
        System.out.println();
        System.out.println("DLugość ciągu: ");
        return max;
    }

    public static int podciag (int[] tab, int r){
        int max = 0;
        int teraz = 1;
        for (int i = 0; i < tab.length-1; i++) {
            if(tab[i] + r == tab[i+1]){
                teraz++;
                max = Math.max(max, teraz);
            }
            else teraz = 1;
        }
        for (int i = 0; i < tab.length; i++) {
            System.out.print(tab[i] + " ");
        }
        System.out.println();
        System.out.println("DLugość ciągu: ");
        return max;
    }

    public static void main(String[] args) {
        int[] podciag = {0,1,2,0,0,1,3,5,6,0,1,4};
        System.out.println(podciag(podciag));
        System.out.println(podciag(podciag,1));
    }
}
