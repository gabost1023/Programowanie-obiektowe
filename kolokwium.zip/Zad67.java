import java.util.Scanner;

public class Zad67 {

    public static void sekwencjaCollatza(int n, int c){
        if(c>0) {
            for (int i = c; i < n+c; i++) {
                if (i % 2 == 0) {
                    int liczba = i/2;
                    System.out.print(liczba + " ");
                }
                else {
                    int liczba = i*3 + 1;
                    System.out.print(liczba + " ");
                }
            }
        }
    }

    public static void minMaxSekwencjaCollatza(int n, int c){
        int[] tab = new int[n+c];
        if(c>0) {
            for (int i = c; i < n+c; i++) {
                if (i % 2 == 0) {
                    tab[i] = i/2;
                }
                else {
                    tab[i] = i*3 + 1;
                }
            }
        }
        int min = tab[c];
        int max = tab[0];
        for (int i = c; i < tab.length; i++) {
            if (tab[i] < min) {
                min = tab[i];
            }
            if (tab[i] > max) {
                max = tab[i];
            }
        }
        System.out.println("min = " + min + " max = " + max);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Podaj n: ");
        int n = sc.nextInt();
        System.out.print("Podaj c: ");
        int c = sc.nextInt();
        sekwencjaCollatza(n,c);
        minMaxSekwencjaCollatza(n, c);
    }
}
